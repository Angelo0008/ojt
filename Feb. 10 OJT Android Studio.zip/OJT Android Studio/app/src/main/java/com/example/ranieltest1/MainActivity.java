package com.example.ranieltest1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ranieltest1.LocalDB.LocalDBHelper;
import com.example.ranieltest1.Model.UserModel;


public class MainActivity extends AppCompatActivity {
    boolean isplayer1;
    LocalDBHelper localDBHelper;
    UserModel user_data;

    String inpUsername, dbUsername, inpPassword, dbPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Home");
        localDBHelper = new LocalDBHelper(this);
        localDBHelper.StartWork();

        user_data = new UserModel();

    }

    public void Settings(View view) {
        Intent i = new Intent(this, MainActivity2.class);
        startActivity(i);
    }

    public void Login(View view) {
        EditText name = findViewById(R.id.inputusername);
        String p = name.getText().toString();


        EditText inputusername = findViewById(R.id.inputusername);
        EditText inputpassword = findViewById(R.id.inputpassword);
        inpUsername = inputusername.getText().toString();
        inpPassword = inputpassword.getText().toString();

        System.out.println("inpUsername: "+ inpUsername);
        user_data  =  localDBHelper.getUserLoginInfo( inpUsername , inpPassword);

        dbUsername = user_data.getUsername();
        dbPassword = user_data.getPassword();

        System.out.println( inputusername.equals(dbUsername) && inputpassword.equals(dbPassword) );
        if( inputusername.getText().toString().equals(dbUsername) && inputpassword.getText().toString().equals(dbPassword) )
        {
            Intent firstpage = new Intent(this, MainScreen.class);
            startActivity(firstpage);
        }
        else
        {
            Toast.makeText(this, "Input Error", Toast.LENGTH_SHORT).show();
        }







    }

    public void Registration(View view) {
        Intent i = new Intent(this, Registration.class);
        startActivity(i);
    }
}