package com.example.feb13androidstudio.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;


import com.example.feb13androidstudio.Model.UserModel;
import com.example.feb13androidstudio.R;

import java.util.List;

public class UserAdapter extends ArrayAdapter<UserModel> {


    private Context mContext;
    int mResource;


    public UserAdapter(Context context, int resource, List<UserModel> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
    }



    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        try {
            Integer id = getItem(position).getId();
            String username = getItem(position).getUsername();
            String firstname = getItem(position).getFirstname();
            String lastname = getItem(position).getLastname();
//
            LayoutInflater inflater = LayoutInflater.from(mContext);
            convertView = inflater.inflate(mResource, parent, false);

            TextView id_textView = (TextView) convertView.findViewById(R.id.hiddenid);
            id_textView.setText(id);

            TextView username_textView = (TextView) convertView.findViewById(R.id.uname);
            username_textView.setText(username);
//
            TextView fname_textView = (TextView) convertView.findViewById(R.id.fname);
            fname_textView.setText(firstname);

            TextView lname_textView = (TextView) convertView.findViewById(R.id.lname);
            lname_textView.setText(lastname);
//


        } catch (Exception e) {
            e.printStackTrace();
        }
        return convertView;
    }



}