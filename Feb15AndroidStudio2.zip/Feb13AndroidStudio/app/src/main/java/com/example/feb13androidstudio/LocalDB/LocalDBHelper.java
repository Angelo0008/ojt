package com.example.feb13androidstudio.LocalDB;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;

import com.example.feb13androidstudio.Model.UserModel;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class LocalDBHelper extends SQLiteOpenHelper {

    public static String dbName = "ranieldb.db";

    public static int dbVersion = 2;
    public static String dbPath = "";
    Context myContext;
    SQLiteDatabase db;
    Cursor cursor = null;


    public LocalDBHelper(Context context) {
        super(context, dbName, null, dbVersion);
        myContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }


    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            db.disableWriteAheadLogging();
        }
    }

    private boolean ExistDatabase() {
        File myFile = new File(dbPath + dbName);
        return myFile.exists();

    }

    private void CopyDatabase() {
        try {
            InputStream myInput = myContext.getAssets().open(dbName);
            OutputStream myOutput = new FileOutputStream(dbPath + dbName);
            byte[] myBuffer = new byte[2048];
            int length;
            while ((length = myInput.read(myBuffer)) > 0) {
                myOutput.write(myBuffer, 0, length);
            }
            myOutput.flush();
            myOutput.close();
            myInput.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    public void StartWork() {
        dbPath = myContext.getFilesDir().getParent() + "/databases/";
        if (!ExistDatabase()) {
            this.getWritableDatabase();
            CopyDatabase();
        } else {
            this.getWritableDatabase();
        }
    }


    public boolean insertUsername(String username, String firstname, String middlename, String lastname, String password) {
        db = getWritableDatabase();
        try {
//            db.execSQL("INSERT INTO auth_user(user_name ) VALUES('" + u.getUser_id() + "', '" + u.getApi_token() + "', '" + u.getRole_id() + "' , '" + u.getWarehouse_id() + "','"+u.getUser_type_id()+  "', '" + u.getCountry_id() + "' , '" + u.getCargo_type_id()  +"')");
            db.execSQL("INSERT INTO auth_user(username, firstname, middlename, lastname, password) VALUES('" + username + "', '" + firstname + "', '" + middlename + "', '" + lastname + "', '" + password + "')");
            System.out.println(">>>>>>insertUsername [username]" + username);

        } catch (Exception e) {
            System.out.println("EXCEPTION ERROR: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
        return true;

    }

    public boolean usernameChecker(String username) {
        db = getWritableDatabase();
        try {
          cursor = db.rawQuery("SELECT COUNT (username) > 0  AS is_existing FROM auth_user WHERE username =  '"+ username+ "'", null);;

        } catch (Exception e) {
            System.out.println("EXCEPTION ERROR [s]: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
        return true;
    }




    public List<UserModel> getListOfUsers() {

        db = getReadableDatabase();
        List<UserModel> list = new ArrayList<>();
        try {
            cursor = db.rawQuery("SELECT id, username, firstname, lastname, password FROM auth_user", null);
            if ( cursor.moveToFirst() ) {
                do {
                    UserModel data = new UserModel();

                    data.setId(cursor.getInt(0));
                    data.setUsername(cursor.getString(1));
                    data.setFirstname(cursor.getString(2));
                    data.setLastname(cursor.getString(3));
                    data.setPassword(cursor.getString(4));


                    list.add(data);

                } while ( cursor.moveToNext() );
            }
            if (cursor != null) {
                cursor.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;

    }


    public UserModel getUserLoginInfo(String username, String password) {

        db = getReadableDatabase();
        UserModel data = new UserModel();
        try {
            cursor = db.rawQuery("SELECT id, username, password FROM auth_user WHERE username = '"+ username+ "' and password = '"+ password+ "'", null);
            if (cursor.moveToFirst()) {

                data.setId( cursor.getInt(0) ) ;
                data.setUsername( cursor.getString(1) );
                data.setPassword( cursor.getString(2) );
            }

            if (cursor != null) {
                cursor.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return data;

    }


    public int getUserId() {
        db = getReadableDatabase();
        try {
            cursor = db.rawQuery("SELECT user_id FROM user LIMIT 1", null);
            if (cursor.moveToFirst()) {
                return cursor.getInt(0);
            }

            if (cursor != null) {
                cursor.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    public int getUserTypeId() {
        db = getReadableDatabase();
        try {
            cursor = db.rawQuery("SELECT user_type_id FROM user LIMIT 1", null);
            if (cursor.moveToFirst()) {
                return cursor.getInt(0);
            }

            if (cursor != null) {
                cursor.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    public int getRoleId() {
        db = getReadableDatabase();
        try {
            cursor = db.rawQuery("SELECT role_id FROM user LIMIT 1", null);
            if (cursor.moveToFirst()) {
                return cursor.getInt(0);
            }

            if (cursor != null) {
                cursor.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;

    }

    public int getWarehouseId() {
        db = getReadableDatabase();
        try {
            cursor = db.rawQuery("SELECT warehouse_id FROM user LIMIT 1", null);
            if (cursor.moveToFirst()) {
                return cursor.getInt(0);
            }

            if (cursor != null) {
                cursor.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    public int getCargoTypeId() {
        db = getReadableDatabase();
        try {
            cursor = db.rawQuery("SELECT cargo_type_id FROM user LIMIT 1", null);
            if (cursor.moveToFirst()) {
                return cursor.getInt(0);
            }

            if (cursor != null) {
                cursor.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }


    public String getApiToken() {
        db = getReadableDatabase();
        try {
            cursor = db.rawQuery("SELECT api_token FROM user LIMIT 1", null);
            if (cursor.moveToFirst()) {
                return cursor.getString(0);
            }

            if (cursor != null) {
                cursor.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "";
    }
    public boolean update(Integer id, String username, String firstname, String lastname) {
        db = getWritableDatabase();
        try {
            db.execSQL("UPDATE auth_user SET username = '" + username + "' , firstname = '" + firstname + "', lastname = '" + lastname + "' WHERE id = '" + id + "'");
            System.out.println(">>>>>>insertUsername [username]" + username);

        } catch (Exception e) {
            System.out.println("EXCEPTION ERROR: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
        return true;

    }
    public void delete_user(Integer ID) {
        db = getWritableDatabase();
        try {
            db.execSQL("DELETE FROM auth_user WHERE id = '"+ ID + "'");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}    /***
     * ****************************************FOR ACCEPTANCE START******************************************************
     */

//    public List<AcceptanceModel> getSavedDimensionMawb(String airlines) {
//        db = getReadableDatabase();
//        List<AcceptanceModel> list=new ArrayList<>();
//
//        try {
//            cursor = db.rawQuery("SELECT id,ailines,mawb_no,origin,destination,flight_no,flight_date,handling_code,awb_pcs,awb_weight,awb_volume,rcv_pcs,rcv_weight,rcv_volume,rcv_date_time,rcv_pcs,rcv_weight,rcv_volume FROM mawb_info where ailines='"+airlines+"'", null);
//            if (cursor.moveToFirst()) {
//                do{
//                    AcceptanceModel acc=new AcceptanceModel();
//                    acc.setId(cursor.getInt(0));
//                    acc.setAirlines(cursor.getString(1));
//                    acc.setMawb_number(cursor.getString(2));
//                    acc.setMawb_origin(cursor.getString(3));