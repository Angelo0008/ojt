package com.example.feb10practice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.feb10practice.Adapter.UserAdapter;
import com.example.feb10practice.LocalDB.LocalDBHelper;
import com.example.feb10practice.Model.UserModel;

import java.util.ArrayList;
import java.util.List;

public class ListOfUsers extends AppCompatActivity {
    ArrayList <String> users = new ArrayList<String>();
    List<UserModel> userList;
    ListView listview;
    LocalDBHelper localdbhelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_of_users);

        localdbhelper = new LocalDBHelper(this);
        userList = localdbhelper.getListOfUsers() ;
//        users.add("carl");
//        users.add("angelo");
//        users.add("rey");
//
//        listview = (ListView) findViewById(R.id.userlistview);
//        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, R.layout.activity_user_listview, R.id.userstext, users);
//        listview.setAdapter(arrayAdapter);
//
        listview = (ListView) findViewById(R.id.userlistview);
        UserAdapter viewAdapter = new UserAdapter(this, R.layout.activity_user_listview, userList);
        listview.setAdapter(viewAdapter);
    }
}