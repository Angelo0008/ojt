package com.example.feb13androidstudio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.feb13androidstudio.Adapter.UserAdapter;
import com.example.feb13androidstudio.LocalDB.LocalDBHelper;
import com.example.feb13androidstudio.Model.UserModel;

import java.util.ArrayList;
import java.util.List;

public class AddUserWindow extends AppCompatActivity {
    View adduserscreen;
    View edituserscreen;

    public EditText username, firstname, middlename, lastname, password;
    String inputusername, inputfirstname, inputmiddlename, inputlastname, inputpassword;
    ListView listview;

    //ArrayList<String> users = new ArrayList<String>();

    List<UserModel> userlist;


    LocalDBHelper localdbhelper;
    UserModel usermodel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user_window);

        localdbhelper = new LocalDBHelper(this);
        //localdbhelper.StartWork();

        usermodel = new UserModel();
        userlist = localdbhelper.getListOfUsers();



        listview = (ListView) findViewById(R.id.userslistview);
        UserAdapter1 viewAdapter = new UserAdapter1(this, R.layout.activity_list_view_users, userlist);
        listview.setAdapter(viewAdapter);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

           usermodel.getId();


                System.out.println("LIST VIEW ID: " +     usermodel.getId());


            }
        });
        //users.add("carl");
        //users.add("angelo");

        /*listview = (ListView) findViewById(R.id.userslistview);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String> (this, R.layout.activity_list_view_users, R.id.userslistviewtext, users);
        listview.setAdapter(arrayAdapter);*/
    }
    public void AddUserPopUp(View view)
    {
        adduserscreen = findViewById(R.id.adduserscreen);
        adduserscreen.setVisibility(View.VISIBLE);
    }
    public void DisableAddUserPopUp(View view)
    {
        adduserscreen = findViewById(R.id.adduserscreen);
        adduserscreen.setVisibility(View.INVISIBLE);
    }
    public void EditUserPopUp(View view)
    {
        edituserscreen = findViewById(R.id.edituserscreen);
        edituserscreen.setVisibility(View.VISIBLE);
    }
    public void DisableEditUserPopUp(View view)
    {
        edituserscreen = findViewById(R.id.edituserscreen);
        edituserscreen.setVisibility(View.INVISIBLE);
    }
    public void Add(View view)
    {
        username = findViewById(R.id.username);
        firstname = findViewById(R.id.firstname);
        middlename = findViewById(R.id.middlename);
        lastname = findViewById(R.id.lastname);
        password = findViewById(R.id.password);

        inputusername = username.getText().toString();
        inputfirstname = firstname.getText().toString();
        inputmiddlename = middlename.getText().toString();
        inputlastname = lastname.getText().toString();
        inputpassword = password.getText().toString();

        localdbhelper.insertUsername(inputusername, inputfirstname, inputmiddlename, inputlastname, inputpassword);
        Toast.makeText(this, "Add Successfully", Toast.LENGTH_SHORT).show();
        Intent i = new Intent(this, AddUserWindow.class);
        startActivity(i);
    }
    public void Edit(int id)
    {
        username = findViewById(R.id.editusername);
        firstname = findViewById(R.id.editfirstname);
        middlename = findViewById(R.id.editmiddlename);
        lastname = findViewById(R.id.editlastname);
        password = findViewById(R.id.editpassword);

          inputusername = username.getText().toString();
//        inputfirstname = firstname.getText().toString();
//        inputmiddlename = middlename.getText().toString();
//        inputlastname = lastname.getText().toString();
//        inputpassword = password.getText().toString();

        localdbhelper.update(id, inputusername);
        Toast.makeText(this, "Edit Successfully", Toast.LENGTH_SHORT).show();
        Intent i = new Intent(this, AddUserWindow.class);
        startActivity(i);
    }


    public void Delete(View view)
    {
        view = getLayoutInflater().inflate(R.layout.activity_list_view_users, null);
        TextView id = view.findViewById(R.id.hiddenid);


        String ID = id.getText().toString();
        System.out.println(">>>>>>>>ID:" + ID);
//        localdbhelper.delete_user(ID);
//        Intent i = new Intent(this, AddUserWindow.class);
//        startActivity(i);
    }
    public void Delete2()
    {
        Intent i = new Intent(this, AddUserWindow.class);
        startActivity(i);
    }


    public class UserAdapter1 extends ArrayAdapter<UserModel> {


        private Context mContext;
        int mResource;


        public UserAdapter1(Context context, int resource, List<UserModel> objects) {
            super(context, resource, objects);
            mContext = context;
            mResource = resource;
        }



        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            try {
                Integer dbid = getItem(position).getId();
                String id = dbid.toString();

                String username = getItem(position).getUsername();
                String firstname = getItem(position).getFirstname();
                String lastname = getItem(position).getLastname();
//
                LayoutInflater inflater = LayoutInflater.from(mContext);
                convertView = inflater.inflate(mResource, parent, false);


                ImageButton deletebutton = convertView.findViewById(R.id.imageButton10);
                ImageButton editbutton = convertView.findViewById(R.id.imageButton9);

                TextView id_textView = (TextView) convertView.findViewById(R.id.hiddenid);
                id_textView.setText(id);

                TextView username_textView = (TextView) convertView.findViewById(R.id.uname);
                username_textView.setText(username);
//
                TextView fname_textView = (TextView) convertView.findViewById(R.id.fname);
                fname_textView.setText(firstname);

                TextView lname_textView = (TextView) convertView.findViewById(R.id.lname);
                lname_textView.setText(lastname);

                deletebutton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        System.out.println("ID>>>"+getItem(position).getId());
                        Integer i = getItem(position).getId();
                        localdbhelper.delete_user(i);

                        Delete2();

                    }
                });

                editbutton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Integer id = getItem(position).getId();
                        Edit(id);
                    }
                });


//


            } catch (Exception e) {
                e.printStackTrace();
            }
            return convertView;
        }



    }

}