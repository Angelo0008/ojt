package com.example.feb13androidstudio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.feb13androidstudio.Adapter.UserAdapter;
import com.example.feb13androidstudio.LocalDB.LocalDBHelper;
import com.example.feb13androidstudio.Model.UserModel;

import java.util.ArrayList;
import java.util.List;

public class AddUserWindow extends AppCompatActivity {
    View adduserscreen;
    View edituserscreen;

    EditText username, firstname, middlename, lastname, password;
    String inputusername, inputfirstname, inputmiddlename, inputlastname, inputpassword;
    ListView listview;

    //ArrayList<String> users = new ArrayList<String>();

    List<UserModel> userlist;


    LocalDBHelper localdbhelper;
    UserModel usermodel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user_window);

        localdbhelper = new LocalDBHelper(this);
        //localdbhelper.StartWork();

        usermodel = new UserModel();
        userlist = localdbhelper.getListOfUsers();



        listview = (ListView) findViewById(R.id.userslistview);
        UserAdapter viewAdapter = new UserAdapter(this, R.layout.activity_list_view_users, userlist);
        listview.setAdapter(viewAdapter);

        //users.add("carl");
        //users.add("angelo");

        /*listview = (ListView) findViewById(R.id.userslistview);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String> (this, R.layout.activity_list_view_users, R.id.userslistviewtext, users);
        listview.setAdapter(arrayAdapter);*/
    }
    public void AddUserPopUp(View view)
    {
        adduserscreen = findViewById(R.id.adduserscreen);
        adduserscreen.setVisibility(View.VISIBLE);
    }
    public void DisableAddUserPopUp(View view)
    {
        adduserscreen = findViewById(R.id.adduserscreen);
        adduserscreen.setVisibility(View.INVISIBLE);
    }
    public void EditUserPopUp(View view)
    {
        edituserscreen = findViewById(R.id.edituserscreen);
        edituserscreen.setVisibility(View.VISIBLE);
    }
    public void DisableEditUserPopUp(View view)
    {
        edituserscreen = findViewById(R.id.edituserscreen);
        edituserscreen.setVisibility(View.INVISIBLE);
    }
    public void Add(View view)
    {
        username = findViewById(R.id.username);
        firstname = findViewById(R.id.firstname);
        middlename = findViewById(R.id.middlename);
        lastname = findViewById(R.id.lastname);
        password = findViewById(R.id.password);

        inputusername = username.getText().toString();
        inputfirstname = firstname.getText().toString();
        inputmiddlename = middlename.getText().toString();
        inputlastname = lastname.getText().toString();
        inputpassword = password.getText().toString();

        localdbhelper.insertUsername(inputusername, inputfirstname, inputmiddlename, inputlastname, inputpassword);
        Toast.makeText(this, "Add Successfully", Toast.LENGTH_SHORT).show();
        Intent i = new Intent(this, AddUserWindow.class);
        startActivity(i);
    }
    public void Edit(View view)
    {
        username = findViewById(R.id.editusername);
        firstname = findViewById(R.id.editfirstname);
        middlename = findViewById(R.id.editmiddlename);
        lastname = findViewById(R.id.editlastname);
        password = findViewById(R.id.editpassword);

        inputusername = username.getText().toString();
        inputfirstname = firstname.getText().toString();
        inputmiddlename = middlename.getText().toString();
        inputlastname = lastname.getText().toString();
        inputpassword = password.getText().toString();

        localdbhelper.update(inputusername, inputfirstname, inputmiddlename, inputlastname, inputpassword);
        Toast.makeText(this, "Edit Successfully", Toast.LENGTH_SHORT).show();
        Intent i = new Intent(this, AddUserWindow.class);
        startActivity(i);
    }
    public void Delete(View view)
    {
        TextView Username = findViewById(R.id.uname);
        String uname = Username.getText().toString();
        localdbhelper.delete_user(uname);
        Intent i = new Intent(this, AddUserWindow.class);
        startActivity(i);
    }
    /*public void Delete2(View view)
    {
        localdbhelper.delete_user(uname);
        Intent i = new Intent(this, AddUserWindow.class);
        startActivity(i);
    }*/

}