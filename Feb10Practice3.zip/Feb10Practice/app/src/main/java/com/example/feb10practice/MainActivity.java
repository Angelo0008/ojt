package com.example.feb10practice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.feb10practice.LocalDB.LocalDBHelper;
import com.example.feb10practice.Model.UserModel;

public class MainActivity extends AppCompatActivity {

    LocalDBHelper localdbhelper;
    UserModel usermodel;
    String inputusername, dbusername;
    String inputpassword, dbpassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        localdbhelper = new LocalDBHelper(this);
        usermodel = new UserModel();
        localdbhelper.StartWork();


    }
    public void Login(View view)
    {
        EditText username = findViewById(R.id.inputusername);
        EditText password = findViewById(R.id.inputpassword);
        inputusername = username.getText().toString();
        inputpassword = password.getText().toString();

        usermodel = localdbhelper.getUserLoginInfo(inputusername, inputpassword);

        dbusername = usermodel.getUsername();
        dbpassword = usermodel.getPassword();

        if(inputusername.equals(dbusername) && inputpassword.equals(dbpassword))
        {
            Intent i = new Intent(this, Home.class);
            startActivity(i);
        }
        else
        {
            Toast.makeText(this, "Input Error", Toast.LENGTH_SHORT).show();
        }


    }
    public void Register(View view)
    {
        Intent i = new Intent(this, Register.class);
        startActivity(i);
    }
}