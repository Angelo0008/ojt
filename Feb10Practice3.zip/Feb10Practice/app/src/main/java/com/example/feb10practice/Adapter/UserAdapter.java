package com.example.feb10practice.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;


import com.example.feb10practice.Model.UserModel;
import com.example.feb10practice.R;

import java.util.List;

public class UserAdapter extends ArrayAdapter<UserModel> {


    private Context mContext;
    int mResource;


    public UserAdapter(Context context, int resource, List<UserModel> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
    }



    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        try {

            String username = getItem(position).getUsername();
            String password = getItem(position).getPassword();
//
            LayoutInflater inflater = LayoutInflater.from(mContext);
            convertView = inflater.inflate(mResource, parent, false);

//
            TextView username_textView = (TextView) convertView.findViewById(R.id.username);
            username_textView.setText(username);
//


        } catch (Exception e) {
            e.printStackTrace();
        }
        return convertView;
    }



}