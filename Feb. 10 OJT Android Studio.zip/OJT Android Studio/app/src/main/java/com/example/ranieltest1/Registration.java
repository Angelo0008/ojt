package com.example.ranieltest1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.ranieltest1.LocalDB.LocalDBHelper;

public class Registration extends AppCompatActivity implements AdapterView.OnItemSelectedListener {


    EditText username, firstname, middlename, lastname, password;

    Button btn_submit ;

    LocalDBHelper localDBHelper;

    Spinner role;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        init();
        spinner();


       btn_submit.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               //save username to db
               System.out.println("username>>>>>>>>" + username.getText().toString());
               System.out.println(">>>>>role : "+role.getSelectedItem().toString());

          //username checker
               System.out.println("usernamechecker>>>>>>>>>>>>>>>");
               System.out.println( localDBHelper.usernameChecker(username.getText().toString()) );
               System.out.println("usernamechecker>>>>>>>>>>>>>>>");
              if(!localDBHelper.usernameChecker(username.getText().toString()))
              {
                  Toast.makeText(Registration.this, "Username Already exist", Toast.LENGTH_SHORT).show();
              }
              else
              {
                  System.out.println(username.toString().trim());
                  //if(username.getText().toString().trim().equals("") || username.getText().toString().trim() ==null )
                  if(username.getText().toString().trim().equals("") || firstname.getText().toString().trim().equals("") || lastname.getText().toString().trim().equals("") || password.getText().toString().trim().equals(""))
                  {
                      Toast.makeText(Registration.this, "Input Field Required", Toast.LENGTH_SHORT).show();
                  }
                  else
                  {
                      System.out.println("insert");
                      localDBHelper.insertUsername( username.getText().toString() , firstname.getText().toString()
                              , middlename.getText().toString() , lastname.getText().toString() , password.getText().toString() , role.getSelectedItem().toString());
                  }

              }


           }
       });
    }

    public void init(){
        //init edit text
        username = findViewById(R.id.username);
        firstname = findViewById(R.id.firstname);
        middlename = findViewById(R.id.middlename);
        lastname = findViewById(R.id.lastname);
        password = findViewById(R.id.password);
        role = findViewById(R.id.role_id);

        //init button submit
        btn_submit = findViewById(R.id.submit);

        //initialize LocalDBHelper
        localDBHelper = new LocalDBHelper(this);
    }
    public void spinner()
    {
        Spinner spinner = (Spinner) findViewById(R.id.role_id);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.role, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        String s = adapterView.getItemAtPosition(i).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}